-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2022 at 05:38 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apitest`
--

-- --------------------------------------------------------

--
-- Table structure for table `gla_well_inquiry`
--

CREATE TABLE `gla_well_inquiry` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `requirement` varchar(255) NOT NULL,
  `units` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `party_name` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gla_well_inquiry`
--

INSERT INTO `gla_well_inquiry` (`id`, `product_name`, `requirement`, `units`, `remark`, `party_name`, `company_name`, `phone`, `email`, `location`, `country`, `state`, `city`, `datetime`) VALUES
(7, '', '', '', '', '', 'dsvfdsgfd', '+917894561230', 'test@gmail.com', '', '', '', '', '2022-01-03 14:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `highen_inquiry`
--

CREATE TABLE `highen_inquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `project_type` varchar(255) NOT NULL,
  `project_stage` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `project_description` varchar(255) NOT NULL,
  `communication` varchar(255) NOT NULL,
  `upload_file` varchar(255) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `highen_inquiry`
--

INSERT INTO `highen_inquiry` (`id`, `name`, `email`, `phone`, `website`, `company_name`, `country`, `project_type`, `project_stage`, `price`, `project_description`, `communication`, `upload_file`, `datetime`) VALUES
(1, '', '', '', '', '', '', '', '', '', '', '', '', '2021-12-31 18:32:41'),
(2, '', '', '', '', '', '', '', '', '', '', '', '', '2022-01-03 12:57:22'),
(3, 'test', 'test@gmail.com', '+917894561230', 'www.test.com', 'glasier', '', '', '', '', 'gerthhfgfsdvdfsv', '', '2349e35e9a295eb108a05171c1c750b6', '2022-01-03 14:31:33'),
(4, 'test', 'pavan@glasier.in', '+911234567890', 'www.test.com', 'testing', '', '', '', '', 'fgdfg', '', '', '2022-01-04 11:15:50'),
(5, 'ddc dcccv', 'test@gmail.com', '888988988', 'www.test.com', 'sdffdsfdf', '', '', '', '', 'scfsdfff', '', 'e95551a8d3acc39b6d581961162d737f', '2022-01-04 11:18:29'),
(6, 'ddc dcccv', 'test@test.com', '7878787878787', 'www.demo.com', 'dfdsfdf', 'Array', 'Array', 'Array', 'Array', 'dsfdsdfd', 'Array', 'e95551a8d3acc39b6d581961162d737f', '2022-01-04 12:03:52'),
(7, 'pavan', 'pavan@glasier.in', '+917894561230', 'www.test.com', 'company name demo', 'India', 'Mobile App Development,Web Development,UI/UX Designing,Dedicated resource hiring', 'Ongoing Project', '$10,000 to $25,000', 'hello', 'Phone', 'e95551a8d3acc39b6d581961162d737f', '2022-01-04 12:06:48');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `age` int(10) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `age`, `city`) VALUES
(48, 'pavan', 25, 'indore'),
(49, 'Kumar', 22, 'indore'),
(51, 'Kumar Vishwas', 25, 'Mumbai'),
(63, 'pavan', 3, 'dcfd'),
(64, 'ddc dcccv', 44, 'dfff'),
(65, 'test', 22, 'testing'),
(66, 'demo', 33, 'demo'),
(67, 'demo1', 55, 'ADI'),
(68, 'pavan vishwakarma', 26, 'Mandsour');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gla_well_inquiry`
--
ALTER TABLE `gla_well_inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `highen_inquiry`
--
ALTER TABLE `highen_inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gla_well_inquiry`
--
ALTER TABLE `gla_well_inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `highen_inquiry`
--
ALTER TABLE `highen_inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
